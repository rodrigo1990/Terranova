<footer>
	<div class="container">
		<ul class="flex">
			<li> 
			
				<img class="logo" src=" <?php echo asset('storage/img/logo-footer.svg') ?> " alt="" > 

			</li>
			
			<li>
				
				<p>
				
					<b>Zona Norte</b>
					Tel 5275-6360 / E-mail: ventas@terranova-sa.com.ar

				</p>
				
				<p>
					
					<b>Zona Sur</b>
					  Tel 4214-3271 / E-mail: info@terranova-sa.com.ar			


				</p>
			</li>
			
			<li>
				<ul class="rrss flex">
					<li>
						<a href="{{$fb}}" target="_blank">
							<i class="fab fa-facebook-f"></i>
						</a>
					</li>
					<li>
						<a href="{{$ig}}" target="_blank">
							<i class="fab fa-instagram"></i>
						</a>
					</li>
					<li>
						<a href="{{$yt}}" target="_blank">
							<i class="fab fa-youtube"></i>
						</a>
					</li>
					</ul>
			</li>
		</ul>
	</div>
</footer>