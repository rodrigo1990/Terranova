
<h1>FORMULARIO TERRANOVA</h1>

<b>Nombre:</b> {{$consulta->nombre}}<br>
<b>Email:</b> {{$consulta->email}}<br>
<b>Teléfono:</b> {{$consulta->telefono}}<br>
<b>Barrio de interes:</b> {{$consulta->proyecto}}<br>
<b>Consulta:</b> {{$consulta->consulta}}<br>

