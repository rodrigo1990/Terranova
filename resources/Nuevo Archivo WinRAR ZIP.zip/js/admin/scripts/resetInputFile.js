window.resetInputFile = function(id){


				$("#file-input-"+id+"").val('');


				 $("#file-img-"+id+"").html('');

			}